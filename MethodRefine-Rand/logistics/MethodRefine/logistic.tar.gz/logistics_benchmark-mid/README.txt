All the necessary files for the experiment are included in this directory. The "generateBenchmark_satellite.py" is used to generate instance in random way. The "satellite.py" is the domain file. 

To get the result, just run "python exec.py" in this directory.
